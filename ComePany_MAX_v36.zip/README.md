# ComePany MAX v36

ComePany is the customer-facing AI companion concept powered by 4MAXXXX / 4maxxAI.

## Prototype
This repository contains a self-contained browser prototype for the ComePany experience:
- Personal and Business modes
- MAX agent identity
- Voice/chat-style interaction UI
- Memory/context panel
- Tasks and daily organization
- Research/action quick actions
- Privacy and permissions messaging
- Responsive mobile-first interface

This is a product prototype, not a production AI backend. No API keys are included.

## Run
Open `index.html` in a browser, or serve the folder with any static web server.

## Project hierarchy
4maThis AI → 4maxxAI / 4MAXXXX Technology → ComePany

Primary slogan:
"Don't carry technology. Carry intelligence."
