const messages=document.getElementById('messages'),prompt=document.getElementById('prompt'),toast=document.getElementById('toast');
function add(text,who){const d=document.createElement('div');d.className='msg '+who;d.textContent=text;messages.appendChild(d);messages.scrollTop=messages.scrollHeight}
function reply(text){add(text,'max')}
function send(){const v=prompt.value.trim();if(!v)return;add(v,'user');prompt.value='';setTimeout(()=>reply("I’m ready to help. In this prototype, MAX can organize the request, suggest next actions, and keep the conversation moving."),350)}
document.getElementById('sendBtn').onclick=send;prompt.addEventListener('keydown',e=>{if(e.key==='Enter')send()});
document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>{prompt.value=b.dataset.action;send()});
document.getElementById('modeBtn').onclick=()=>{const b=document.getElementById('modeBtn');b.textContent=b.textContent.includes('PERSONAL')?'BUSINESS ▾':'PERSONAL ▾';reply(b.textContent.includes('BUSINESS')?'Business Mode is active. Let’s focus on goals, growth and execution.':'Personal Mode is active. Let’s focus on your life, plans and priorities.')};
document.getElementById('micBtn').onclick=()=>showToast('Voice interface placeholder — connect speech services in the production build.');
document.querySelectorAll('[data-panel]').forEach(b=>b.onclick=()=>showToast(b.dataset.panel==='privacy'?'Privacy and permissions panel selected.':'Panel selected: '+b.dataset.panel));
document.getElementById('settingsBtn').onclick=()=>showToast('Settings panel placeholder.');
function showToast(t){toast.textContent=t;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2200)}
