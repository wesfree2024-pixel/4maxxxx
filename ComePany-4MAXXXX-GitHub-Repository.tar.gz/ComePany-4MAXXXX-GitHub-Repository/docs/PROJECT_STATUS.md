# Project Status — September 27, 2026

## Confirmed naming structure
- Company: 4maThis AI
- Technology: 4maxxAI / 4MAXXXX Technology
- Product: ComePany Business/Personal
- Future hardware: dedicated 4MAXX / ComePany device concept

## Product principles
The experience should communicate clearly, naturally, enjoyably, positively, and encouragingly. The product is intended to support both personal life and business life without forcing the user into separate unrelated AI relationships.

## Modes
- Personal Mode
- Business Mode
- Optional Companion Mode in both modes

## Brand
Primary slogan: “Don't carry technology. Carry intelligence.”

## Security direction
Customer identities, agent identities, business information, memory, credentials, and permissions should be logically isolated. Authentication and authorization belong in the application/backend rather than relying on conversational memory alone.

## Current limitation
This repository contains the available project records and visual assets. A verified application source tree has not yet been recovered from the available ChatGPT files, so no source code is being falsely represented as complete.
