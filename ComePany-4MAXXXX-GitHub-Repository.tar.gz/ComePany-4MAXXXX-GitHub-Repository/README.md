# ComePany / 4MAXXXX

**4maThis AI** — company/business layer  
**4maxxAI** — technology/platform layer  
**ComePany Business/Personal** — flagship product/service concept

> **Don't carry technology. Carry intelligence.**

## Repository purpose

This repository preserves the current ComePany / 4MAXXXX product-development record and provides a GitHub-ready home for future application source code.

### Current product direction
- Personal + Business AI companion experience
- Optional Companion Mode
- Persistent, user-authorized memory/context
- Customer-specific agent identity and personalization
- Planning, organization, research, writing, communications, and business assistance
- Secure backend architecture with customer/account isolation
- Future dedicated ComePany / 4MAXXXX device

### Architecture concept
`Customer → ComePany / 4MAXXXX App → Secure Backend → Authorized AI Services & Tools → Agent → Customer`

API credentials and sensitive secrets must remain server-side; never commit secrets to GitHub.

## Repository status

This is the **GitHub-ready project record**. The current ChatGPT file library contains project records and design assets, but no verified application source-code ZIP. Source code should be added here as it becomes available.

## Important

The records in `records/` document concepts and development direction. They are not substitutes for legal filings, registrations, assignments, contracts, or professional legal advice.

## Next development areas
1. Application source code
2. Authentication and customer/account isolation
3. Agent identity and naming
4. Authorized memory/context
5. Personal and Business modes
6. Voice/text experience
7. Secure backend and API integrations
8. Testing and deployment configuration
