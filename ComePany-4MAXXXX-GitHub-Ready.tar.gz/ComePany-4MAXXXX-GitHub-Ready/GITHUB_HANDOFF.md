# ComePany / 4MAXXXX — GitHub Handoff Package

This package contains the current ComePany / 4MAXXXX project repository record and documentation.

## Current status
The included repository is a project/documentation foundation. It does not yet contain the full production application source tree.

## Brand hierarchy
- Company: 4matThis AI Company
- Technology: 4MAXXXX Technology
- Product/device: ComePany
- Primary positioning: Your AI Company Keeper
- Primary slogan: Don't carry technology. Carry intelligence.

## Next development target
Build the actual application source tree from the approved product concept, preserving the project documentation and branding records in this repository.

## Important
Do not commit real API keys or production secrets. Use environment variables and `.env.example`.
